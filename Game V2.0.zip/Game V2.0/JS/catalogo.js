var identificadores = ["Skins", "Especiais", "Bônus"];


function carrega_dados_lolja(){

    document.getElementById("#identificador").innerHtml = identificadores[categoria_lolja];

}